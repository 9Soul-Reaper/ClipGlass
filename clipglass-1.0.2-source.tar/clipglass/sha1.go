package main

import "math/bits"

// sha1Sum 是精简的 SHA-1(仅用于图片内容去重文件名,与标准库结果一致)。
// 不用 crypto/sha1:它会连带拉入整套 FIPS 加密代码,让 exe 多出约 200KB。
func sha1Sum(p []byte) (out [20]byte) {
	h := [5]uint32{0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0}
	n := len(p)
	tail := make([]byte, 0, 128)
	tail = append(tail, p[n&^63:]...)
	tail = append(tail, 0x80)
	for len(tail)%64 != 56 {
		tail = append(tail, 0)
	}
	bl := uint64(n) * 8
	for i := 56; i >= 0; i -= 8 {
		tail = append(tail, byte(bl>>uint(i)))
	}
	var w [80]uint32
	block := func(b []byte) {
		for i := 0; i < 16; i++ {
			w[i] = uint32(b[4*i])<<24 | uint32(b[4*i+1])<<16 | uint32(b[4*i+2])<<8 | uint32(b[4*i+3])
		}
		for i := 16; i < 80; i++ {
			w[i] = bits.RotateLeft32(w[i-3]^w[i-8]^w[i-14]^w[i-16], 1)
		}
		a, b2, c, d, e := h[0], h[1], h[2], h[3], h[4]
		for i := 0; i < 80; i++ {
			var f, k uint32
			switch {
			case i < 20:
				f, k = b2&c|^b2&d, 0x5A827999
			case i < 40:
				f, k = b2^c^d, 0x6ED9EBA1
			case i < 60:
				f, k = b2&c|b2&d|c&d, 0x8F1BBCDC
			default:
				f, k = b2^c^d, 0xCA62C1D6
			}
			t := bits.RotateLeft32(a, 5) + f + e + k + w[i]
			a, b2, c, d, e = t, a, bits.RotateLeft32(b2, 30), c, d
		}
		h[0] += a
		h[1] += b2
		h[2] += c
		h[3] += d
		h[4] += e
	}
	for i := 0; i+64 <= n; i += 64 {
		block(p[i : i+64])
	}
	for i := 0; i < len(tail); i += 64 {
		block(tail[i : i+64])
	}
	for i, v := range h {
		out[4*i], out[4*i+1], out[4*i+2], out[4*i+3] = byte(v>>24), byte(v>>16), byte(v>>8), byte(v)
	}
	return
}
