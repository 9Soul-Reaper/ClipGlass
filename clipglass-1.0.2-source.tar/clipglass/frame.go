package main

import "math"

// 拖动窗口时每帧都要重建底图,因此把与背景内容无关的部分(高光/光晕叠层、
// 圆角阴影与边缘高光)预先算好缓存,每帧只做整数运算。

// ---- 叠层(顶部高光 + 强调色光晕) ----

type overlay struct {
	key  [8]int
	p    []byte // 预乘后的叠加色 BGR(每像素 4 字节,第 4 字节为 α)
	w, h int
}

func (u *UI) overlayFor(w, h int) *overlay {
	acc := clampi(u.Set.Accent, 0, len(accents)-1)
	key := [8]int{w, h, int(u.S * 100), boolInt(u.Dark), boolInt(u.Set.Glass), acc}
	if u.ov != nil && u.ov.key == key {
		return u.ov
	}
	build := func(bg byte) *Canvas {
		c := NewCanvas(w, h)
		for i := 0; i < len(c.Pix); i += 4 {
			c.Pix[i], c.Pix[i+1], c.Pix[i+2], c.Pix[i+3] = bg, bg, bg, 255
		}
		a0 := 0.16
		if !u.Dark {
			a0 = 0.28
		}
		c.VGradient(Rect{0, 0, w, h * 2 / 5}, Color{255, 255, 255}, a0, 0)
		if u.Set.Glass {
			glow := accents[acc][0]
			ga := 0.10
			if !u.Dark {
				ga = 0.08
			}
			for r := 0; r < 6; r++ {
				c.FillCircle(float64(w)*0.9, float64(h)*0.06, u.fpx(160)-float64(r)*u.fpx(20), glow, ga/3)
			}
		}
		return c
	}
	black, white := build(0), build(255)
	o := &overlay{key: key, p: make([]byte, w*h*4), w: w, h: h}
	for i := 0; i < len(o.p); i += 4 {
		// 黑底得到 P=α·C,白底得到 255(1-α)+P  ⇒  α = 255 - (白-黑)
		a := 255 - (int(white.Pix[i]) - int(black.Pix[i]))
		o.p[i], o.p[i+1], o.p[i+2] = black.Pix[i], black.Pix[i+1], black.Pix[i+2]
		o.p[i+3] = byte(clampi(a, 0, 255))
	}
	u.ov = o
	return o
}

func boolInt(b bool) int {
	if b {
		return 1
	}
	return 0
}

// apply 把叠层合成到 c 上:out = bg·(1-α) + P。
func (o *overlay) apply(c *Canvas, noise []int8) {
	for i, j := 0, 0; i < len(c.Pix); i, j = i+4, j+1 {
		ia := 255 - int(o.p[i+3])
		if noise != nil {
			n := int(noise[j])
			c.Pix[i] = clampB(int(c.Pix[i]) + n)
			c.Pix[i+1] = clampB(int(c.Pix[i+1]) + n)
			c.Pix[i+2] = clampB(int(c.Pix[i+2]) + n)
		}
		if ia == 255 {
			continue
		}
		c.Pix[i] = byte((int(c.Pix[i])*ia+127)/255 + int(o.p[i]))
		c.Pix[i+1] = byte((int(c.Pix[i+1])*ia+127)/255 + int(o.p[i+1]))
		c.Pix[i+2] = byte((int(c.Pix[i+2])*ia+127)/255 + int(o.p[i+2]))
	}
}

// ---- 颜色:整数版染色 + 饱和度 + 抖动噪点 ----

var noiseCache struct {
	w, h int
	n    []int8
}

func noiseTable(w, h int) []int8 {
	if noiseCache.w == w && noiseCache.h == h {
		return noiseCache.n
	}
	n := make([]int8, w*h)
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			hh := uint32(x)*73856093 ^ uint32(y)*19349663
			hh ^= hh >> 13
			hh *= 1274126177
			n[y*w+x] = int8(int(hh>>24)%5 - 2)
		}
	}
	noiseCache.w, noiseCache.h, noiseCache.n = w, h, n
	return n
}

func tintFast(c *Canvas, tint Color, tintA, sat float64) {
	ta := int(tintA*256 + 0.5)
	s := int(sat*256 + 0.5)
	tr, tg, tb := int(tint.R)*ta, int(tint.G)*ta, int(tint.B)*ta
	for i := 0; i < len(c.Pix); i += 4 {
		b, g, r := int(c.Pix[i]), int(c.Pix[i+1]), int(c.Pix[i+2])
		l := (77*r + 150*g + 29*b) >> 8
		r = l + ((r-l)*s)>>8
		g = l + ((g-l)*s)>>8
		b = l + ((b-l)*s)>>8
		c.Pix[i] = clampB((b*(256-ta) + tb) >> 8)
		c.Pix[i+1] = clampB((g*(256-ta) + tg) >> 8)
		c.Pix[i+2] = clampB((r*(256-ta) + tr) >> 8)
		c.Pix[i+3] = 255
	}
}

func clampB(v int) byte {
	if v < 0 {
		return 0
	}
	if v > 255 {
		return 255
	}
	return byte(v)
}

// ---- 圆角、阴影、边缘高光模板 ----

type frameTpl struct {
	key    [8]int
	idx    []int32
	cov    []uint16 // 0..256
	rim    []uint16 // 0..256,向白色混合的比例
	alpha  []uint8
	mask   []byte // 整帧 α 遮罩(只读,由模板决定,与背景内容无关)
	dark   bool
	w, h   int
	m      int
	iw, ih int
}

func frameTemplate(prev *frameTpl, w, h, m, iw, ih int, radius float64, dark bool, shadowPx float64) *frameTpl {
	key := [8]int{w, h, m, iw, ih, int(radius * 100), boolInt(dark), int(shadowPx * 100)}
	if prev != nil && prev.key == key {
		return prev
	}
	t := &frameTpl{key: key, dark: dark, w: w, h: h, m: m, iw: iw, ih: ih}
	cx, cy := float64(m)+float64(iw)/2, float64(m)+float64(ih)/2
	hw, hh := float64(iw)/2, float64(ih)/2
	maxA := 0.38
	rimA := 0.30
	if !dark {
		maxA, rimA = 0.30, 0.75
	}
	ri := int(radius) + 2
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			if (x >= m+ri && x < m+iw-ri && y >= m+2 && y < m+ih-2) ||
				(x >= m+2 && x < m+iw-2 && y >= m+ri && y < m+ih-ri) {
				continue
			}
			d := sdRoundRect(float64(x)+0.5, float64(y)+0.5+shadowPx*0.25, cx, cy, hw, hh, radius)
			dEdge := sdRoundRect(float64(x)+0.5, float64(y)+0.5, cx, cy, hw, hh, radius)
			cov := clamp01(0.5 - dEdge)
			sa := 0.0
			if d > -shadowPx*2 {
				tt := clamp01(1 - math.Max(d, 0)/shadowPx)
				sa = maxA * tt * tt
			}
			band := 0.0
			if dEdge < 0.5 {
				band = clamp01(0.5-dEdge) * clamp01(1.4+dEdge)
			}
			t.idx = append(t.idx, int32((y*w+x)*4))
			t.cov = append(t.cov, uint16(cov*256+0.5))
			t.rim = append(t.rim, uint16(rimA*band*256+0.5))
			t.alpha = append(t.alpha, clampByte((cov+(1-cov)*sa)*255))
		}
	}
	t.mask = make([]byte, w*h)
	for y := m; y < m+ih; y++ {
		for x := m; x < m+iw; x++ {
			t.mask[y*w+x] = 255
		}
	}
	for k, i32 := range t.idx {
		t.mask[int(i32)/4] = t.alpha[k]
	}
	return t
}

// apply 对 base 上的像素套用模板(内部区域须已是不透明内容,外圈为 0)。
func (t *frameTpl) apply(base *Canvas) {
	for k, i32 := range t.idx {
		i := int(i32)
		cov, rim := int(t.cov[k]), int(t.rim[k])
		b, g, r := int(base.Pix[i]), int(base.Pix[i+1]), int(base.Pix[i+2])
		if rim > 0 {
			b += ((255 - b) * rim) >> 8
			g += ((255 - g) * rim) >> 8
			r += ((255 - r) * rim) >> 8
		}
		base.Pix[i] = byte((b * cov) >> 8)
		base.Pix[i+1] = byte((g * cov) >> 8)
		base.Pix[i+2] = byte((r * cov) >> 8)
		base.Pix[i+3] = t.alpha[k]
	}
}

// ---- 前景层:拖动时不再重画文字,而是把“前景相对任意背景”的合成参数缓存下来 ----

// fgLayer 记录 UI 前景(卡片、文字、图标)的合成参数:out = bg·ia/255 + p。
// 分别在纯黑、纯白底上各绘制一次即可求得(ia = 白图 - 黑图,p = 黑图),逐通道,故 ClearType 彩边也能保留。
type fgLayer struct {
	ia, p []byte
}

func newFGLayer(black, white *Canvas) *fgLayer {
	f := &fgLayer{ia: make([]byte, len(black.Pix)), p: make([]byte, len(black.Pix))}
	copy(f.p, black.Pix)
	for i := 0; i < len(f.ia); i += 4 {
		for c := 0; c < 3; c++ {
			f.ia[i+c] = byte(clampi(int(white.Pix[i+c])-int(black.Pix[i+c]), 0, 255))
		}
	}
	return f
}

// mergeInner 把前景层(窗口大小)裁出内部面板区域,并与顶部高光/光晕叠层合并为单一算子:
// 先叠层、后前景:ia = ia₁·ia₂/255,p = p₁·ia₂/255 + p₂。拖动时每帧只需一遍整数运算。
func (f *fgLayer) mergeInner(o *overlay, noise []int8, winW int, in Rect) *fgLayer {
	m := &fgLayer{ia: make([]byte, in.W*in.H*4), p: make([]byte, in.W*in.H*4)}
	for y := 0; y < in.H; y++ {
		for x := 0; x < in.W; x++ {
			k := (y*in.W + x) * 4
			s := ((y+in.Y)*winW + x + in.X) * 4
			oa := 255 - int(o.p[k+3])
			for c := 0; c < 3; c++ {
				fi := int(f.ia[s+c])
				m.ia[k+c] = byte((oa*fi + 127) / 255)
				// 噪点是固定图案,直接折进 p(带 +2 偏置,以便表示负值),每帧不必再单独加噪点
				n := int(noise[y*in.W+x])
				m.p[k+c] = byte(clampi((int(o.p[k+c])*fi+127)/255+int(f.p[s+c])+(n*int(m.ia[k+c])+127)/255+2, 0, 255))
			}
		}
	}
	return m
}

// composeInner 把(已染色的)背景 bg 经合并算子(含噪点,p 带 +2 偏置)写入 dst 的内部面板区域,α 置 255。
func (f *fgLayer) composeInner(dst, bg *Canvas, in Rect) {
	parRows(in.H, func(y0, y1 int) {
		for y := y0; y < y1; y++ {
			d := dst.Pix[((y+in.Y)*dst.W+in.X)*4:][: in.W*4 : in.W*4]
			s := bg.Pix[y*in.W*4:][: in.W*4 : in.W*4]
			ia := f.ia[y*in.W*4:][: in.W*4 : in.W*4]
			p := f.p[y*in.W*4:][: in.W*4 : in.W*4]
			for x := 0; x < in.W; x++ {
				k := x * 4
				// (v·ia+127)/255 的移位近似:((v·ia+128)·257)>>16
				d[k] = clampB(((int(s[k])*int(ia[k])+128)*257)>>16 + int(p[k]) - 2)
				d[k+1] = clampB(((int(s[k+1])*int(ia[k+1])+128)*257)>>16 + int(p[k+1]) - 2)
				d[k+2] = clampB(((int(s[k+2])*int(ia[k+2])+128)*257)>>16 + int(p[k+2]) - 2)
				d[k+3] = 255
			}
		}
	})
}
