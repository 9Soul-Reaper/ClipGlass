//go:build !windows

package main

import "testing"

func TestChipDragScroll(t *testing.T) {
	st := &Store{Dir: t.TempDir()}
	u := NewUI(1, st, defaultSettings())
	in := u.InnerRect()
	x, y := in.X+200, in.Y+u.px(120)
	u.chipMax = 500
	u.ChipPress(x, y)
	u.MouseMove(x-3, y)
	if u.ChipRelease() {
		t.Fatal("小于阈值不应算拖动")
	}
	u.ChipPress(x, y)
	u.MouseMove(x-80, y)
	if u.ChipScroll <= 0 {
		t.Fatalf("向左拖应向右滚动: %v", u.ChipScroll)
	}
	if !u.ChipRelease() {
		t.Fatal("应判定为拖动")
	}
	u.WheelH(120)
	if u.ChipScroll <= 80 {
		t.Fatalf("横向滚轮无效: %v", u.ChipScroll)
	}
}
