package main

// v2.2 新增文案:敏感内容跳过提示、保存失败提示。

func init() {
	strs["t.skipped"] = [5]string{"已跳过一条敏感内容(%s)· 点击仍然记录", "Skipped a sensitive item (%s) — click to keep it", "已跳過一筆敏感內容(%s)· 點擊仍然記錄", "機密の可能性がある内容(%s)を記録しませんでした · クリックで記録", "민감한 내용(%s)을 기록하지 않았습니다 · 클릭하면 기록"}
	strs["t.saveerr"] = [5]string{"历史保存失败,请检查磁盘空间或文件权限", "Couldn't save history — check disk space or permissions", "歷史儲存失敗,請檢查磁碟空間或檔案權限", "履歴を保存できません。空き容量や権限を確認してください", "기록을 저장하지 못했습니다. 디스크 공간이나 권한을 확인하세요"}
	strs["m.xform"] = [5]string{"转换后粘贴", "Paste as…", "轉換後貼上", "変換して貼り付け", "변환 후 붙여넣기"}
	strs["x.urlenc"] = [5]string{"URL 编码", "URL encode", "URL 編碼", "URL エンコード", "URL 인코딩"}
	strs["x.urldec"] = [5]string{"URL 解码", "URL decode", "URL 解碼", "URL デコード", "URL 디코딩"}
	strs["x.b64enc"] = [5]string{"Base64 编码", "Base64 encode", "Base64 編碼", "Base64 エンコード", "Base64 인코딩"}
	strs["x.b64dec"] = [5]string{"Base64 解码", "Base64 decode", "Base64 解碼", "Base64 デコード", "Base64 디코딩"}
	strs["x.jsonfmt"] = [5]string{"JSON 格式化", "Format JSON", "JSON 格式化", "JSON を整形", "JSON 정리"}
	strs["x.jsonmin"] = [5]string{"JSON 压缩", "Minify JSON", "JSON 壓縮", "JSON を圧縮", "JSON 압축"}
	strs["x.trim"] = [5]string{"去空行和行尾空格", "Remove blank lines", "移除空行與行尾空白", "空行と行末空白を除去", "빈 줄·줄 끝 공백 제거"}
	strs["t.xformfail"] = [5]string{"无法转换:内容格式不符", "Can't convert: unexpected format", "無法轉換:內容格式不符", "変換できません:形式が合いません", "변환할 수 없음: 형식이 맞지 않습니다"}
	for i, m := range [9]map[string]string{
		kv("t.skipped", "Se omitió un elemento sensible (%s): haz clic para guardarlo", "t.saveerr", "No se pudo guardar el historial: revisa el espacio o los permisos"),
		kv("t.skipped", "Élément sensible ignoré (%s) — cliquez pour le conserver", "t.saveerr", "Échec de l'enregistrement : vérifiez l'espace disque ou les droits"),
		kv("t.skipped", "Sensibler Eintrag übersprungen (%s) — zum Behalten klicken", "t.saveerr", "Verlauf konnte nicht gespeichert werden — Speicherplatz/Rechte prüfen"),
		kv("t.skipped", "Item sensível ignorado (%s) — clique para manter", "t.saveerr", "Não foi possível salvar o histórico — verifique espaço e permissões"),
		kv("t.skipped", "Конфиденциальный элемент пропущен (%s) — нажмите, чтобы сохранить", "t.saveerr", "Не удалось сохранить историю — проверьте место на диске и права"),
		kv("t.skipped", "Elemento sensibile ignorato (%s) — clicca per mantenerlo", "t.saveerr", "Impossibile salvare la cronologia — controlla spazio e permessi"),
		kv("t.skipped", "Hassas öğe atlandı (%s) — saklamak için tıklayın", "t.saveerr", "Geçmiş kaydedilemedi — disk alanını/izinleri kontrol edin"),
		kv("t.skipped", "Đã bỏ qua mục nhạy cảm (%s) — bấm để vẫn lưu", "t.saveerr", "Không lưu được lịch sử — kiểm tra dung lượng/quyền"),
		kv("t.skipped", "Item sensitif dilewati (%s) — klik untuk tetap menyimpan", "t.saveerr", "Gagal menyimpan riwayat — periksa ruang disk/izin"),
	} {
		for k, v := range m {
			moreLangs[i][k] = v
		}
	}
}
