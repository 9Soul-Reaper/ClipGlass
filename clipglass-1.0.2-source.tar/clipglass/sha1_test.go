package main

import (
	"crypto/sha1"
	"testing"
)

func TestSha1Sum(t *testing.T) {
	for n := 0; n < 300; n++ {
		b := make([]byte, n)
		for i := range b {
			b[i] = byte(i*7 + n)
		}
		if sha1Sum(b) != sha1.Sum(b) {
			t.Fatalf("len %d mismatch", n)
		}
	}
}
