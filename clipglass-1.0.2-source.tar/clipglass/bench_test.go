//go:build !windows

package main

import "testing"

func BenchmarkDragFast(b *testing.B) {
	set := defaultSettings()
	st := &Store{}
	ui := NewUI(1.5, st, set)
	ui.Dark = true
	ui.OnAction = func(*Item, int) {}
	ui.Rebuild()
	W, H := ui.WinSize()
	desk := fakeDesktop(2560, 1440)
	m := makeBlurMap(rawDesk(desk.Pix, desk.W, desk.H), ui.BlurPx(), 0, 0)
	n := W * H * 4
	op := ui.DragOp(&fgLayer{ia: bytesOf(n, 255), p: bytesOf(n, 0)})
	dst := NewCanvas(W, H)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ui.ComposeDragFast(m, 100+i%500, 80+i%300, op, dst)
	}
}

func bytesOf(n int, v byte) []byte {
	b := make([]byte, n)
	for i := range b {
		b[i] = v
	}
	return b
}

func BenchmarkDragFrame(b *testing.B) {
	set := defaultSettings()
	st := &Store{}
	ui := NewUI(1.5, st, set)
	ui.Dark = true
	desk := fakeDesktop(2560, 1440)
	m := makeBlurMap(rawDesk(desk.Pix, desk.W, desk.H), ui.BlurPx(), 0, 0)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ui.ComposeDrag(m, 100+i%500, 80+i%300)
	}
}

// 拖动快速路径(合并算子)的结果应与“重建底图 + 重画界面”几乎一致。
func TestDragFastMatchesDirect(t *testing.T) {
	set := defaultSettings()
	st := &Store{}
	st.Add("hello https://example.com", "x")
	st.Add("zhang@example.com", "y")
	ui := NewUI(1, st, set)
	ui.Dark = true
	ui.OnAction = func(*Item, int) {}
	ui.Rebuild()
	in := ui.InnerRect()
	W, H := ui.WinSize()
	draw := func(base *Canvas) *Canvas {
		c := NewCanvas(W, H)
		copy(c.Pix, base.Pix)
		ui.Draw(c, &stubText{c})
		return c
	}
	flat := func(v byte) *Canvas {
		c := NewCanvas(W, H)
		for i := 0; i < len(c.Pix); i += 4 {
			c.Pix[i], c.Pix[i+1], c.Pix[i+2], c.Pix[i+3] = v, v, v, 255
		}
		return c
	}
	desk := fakeDesktop(1600, 900)
	m := makeBlurMap(rawDesk(desk.Pix, desk.W, desk.H), ui.BlurPx(), 0, 0)
	base, mask := ui.ComposeDrag(m, 200, 100)
	want := draw(base)
	op := ui.DragOp(newFGLayer(draw(flat(0)), draw(flat(255))))
	got := NewCanvas(W, H)
	for i, v := range mask {
		got.Pix[i*4+3] = v
	}
	ui.ComposeDragFast(m, 200, 100, op, got)
	worst := 0
	for y := in.Y; y < in.Y+in.H; y++ {
		for x := in.X; x < in.X+in.W; x++ {
			i := (y*W + x) * 4
			for c := 0; c < 3; c++ {
				d := int(got.Pix[i+c]) - int(want.Pix[i+c])
				if d < 0 {
					d = -d
				}
				if d > worst {
					worst = d
				}
			}
		}
	}
	if worst > 4 {
		t.Fatalf("拖动快速路径误差过大: %d", worst)
	}
}
